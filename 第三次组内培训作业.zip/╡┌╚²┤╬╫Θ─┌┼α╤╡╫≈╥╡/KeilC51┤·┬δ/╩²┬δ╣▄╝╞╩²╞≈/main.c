#include "reg52.h"			 

typedef unsigned int u16;	  //���������ͽ�����������
typedef unsigned char u8;

sbit LSA=P2^2;
sbit LSB=P2^3;
sbit LSC=P2^4;

u8 code smgduan[17]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,
					0x7f,0x6f,0x77,0x7c,0x39,0x5e,0x79,0x71};//��ʾ0~F��ֵ


void delay(u16 i)
{
	while(i--);	
}


void DigDisplay()
{
	u8 i,j,k,l,m;
	for(j=0;j<10;j++)
	{	
		for(k=0;k<10;k++)
		{
			for(l=0;l<10;l++)
			{
				for(m=0;m<10;m++)
				{	
					for(i=0;i<4;i++)
					{
						switch(i)	 						//λѡ��ѡ�����������ܣ�
						{
							case(0):						//��ʾ��0λ
								LSA=0;		   
								LSB=0;
								LSC=0;
								P0=smgduan[j];
								delay(500); 	
								P0=0x00; 
								break;
							case(1):					   	//��ʾ��1λ
								LSA=1;
								LSB=0;				
								LSC=0;
								P0=smgduan[k];
								delay(500); 	
								P0=0x00; 
								break;
							case(2):					   	//��ʾ��2λ
								LSA=0;				   
								LSB=1;
								LSC=0;
								P0=smgduan[l];
								delay(500); 	
								P0=0x00; 
								break;
							case(3):						//��ʾ��3λ
								LSA=1;
								LSB=1;
								LSC=0;
								P0=smgduan[m];
								delay(500); 	
								P0=0x00; 
								break;
					
						}
					}
				}
			}
		}
	}
}

void main()
{	
	while(1)
	{	
		DigDisplay();  //�������ʾ����	
	}		
}
