#include "reg52.h"


typedef unsigned char u8;
typedef unsigned int u16;

#define led P0


void delay(u16 i)
{
	while(i--);
}

void main()
{
	
	while(1)
	{
		led=0xFE;
		delay(50000);
		led=0xFD;
		delay(50000);
		led=0xFB;
		delay(50000);
		led=0xF7;
		delay(50000);
		led=0xEF;
		delay(50000);
		led=0xDF;
		delay(50000);
		led=0xBF;
		delay(50000);
		led=0x7F;
		delay(50000);
	}
}
